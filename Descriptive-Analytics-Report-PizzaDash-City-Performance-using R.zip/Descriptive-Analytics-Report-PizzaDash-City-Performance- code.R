# STEP 1: Load Required Libraries
packages <- c("dplyr", "ggplot2", "readr", "scales", "DT", "shiny")
installed <- rownames(installed.packages())
for (pkg in packages) {
  if (!pkg %in% installed) install.packages(pkg)
}

# Load them
library(dplyr)
library(ggplot2)
library(readr)
library(scales)
library(DT)
library(shiny)

# STEP 2: Input Dataset
# Create the dataset
data <- data.frame(
  City = paste0("City_", 1:20),
  Monthly_Orders = c(1200, 950, 1340, 800, 1100, 720, 1350, 980, 1040, 1150,
                     890, 1230, 990, 875, 1080, 960, 870, 1000, 1190, 940),
  Avg_Delivery_Time_Min = c(28, 35, 26, 40, 30, 42, 25, 34, 32, 29,
                            36, 27, 33, 38, 31, 37, 39, 30, 28, 35),
  Customer_Rating = c(4.2, 3.8, 4.5, 3.5, 4.0, 3.6, 4.6, 3.9, 4.1, 4.3,
                      3.7, 4.4, 4.0, 3.6, 4.2, 3.9, 3.8, 4.0, 4.3, 3.7),
  Top_Complaint = c("Late Delivery", "Cold Pizza", "No Complaint", "Late Delivery", "Wrong Order", "Cold Pizza", "No Complaint",
                    "Late Delivery", "Late Delivery", "Wrong Order", "Cold Pizza", "No Complaint", "Wrong Order",
                    "Cold Pizza", "Late Delivery", "Wrong Order", "Late Delivery", "Cold Pizza", "No Complaint", "Cold Pizza"),
  Positive_Mentions = c(210, 180, 250, 130, 200, 140, 270, 190, 210, 230,
                        160, 240, 200, 170, 220, 185, 175, 195, 225, 165),
  Negative_Mentions = c(40, 75, 20, 90, 50, 85, 15, 70, 55, 45,
                        80, 25, 60, 78, 48, 72, 76, 58, 35, 74)
)

# STEP 3: Normalize and Score
# Create a scoring mechanism
scored_data <- data %>%
  mutate(
    Score = scale(Monthly_Orders) * 0.25 -
      scale(Avg_Delivery_Time_Min) * 0.25 +
      scale(Customer_Rating) * 0.25 +
      scale(Positive_Mentions - Negative_Mentions) * 0.25
  ) %>%
  arrange(desc(Score))

# Select top 5 cities
top_5 <- head(scored_data, 5)

# STEP 4: Visualization
# Bar plot for top 5 cities by Score
ggplot(top_5, aes(x = reorder(City, Score), y = Score, fill = City)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +
  labs(title = "Top 5 Recommended Cities for Expansion",
       x = "City",
       y = "Composite Score") +
  theme_minimal()

# Box plot for delivery time comparison
ggplot(data, aes(y = Avg_Delivery_Time_Min)) +
  geom_boxplot(fill = "skyblue") +
  labs(title = "Delivery Time Distribution", y = "Delivery Time (Min)") +
  theme_minimal()

# STEP 5: Print Table of Top 5
print(top_5[, c("City", "Monthly_Orders", "Avg_Delivery_Time_Min", "Customer_Rating", "Score")])

